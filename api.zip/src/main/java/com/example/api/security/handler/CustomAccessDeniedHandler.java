package com.example.api.security.handler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

import java.io.IOException;

@Log4j2
public class CustomAccessDeniedHandler implements AccessDeniedHandler {
  @Override
  public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
    accessDeniedException.printStackTrace();
    String tmp = accessDeniedException.getMessage();
    if(tmp.contains("403")){
      response.sendError(HttpServletResponse.SC_FORBIDDEN);
    }
      response.sendRedirect(request.getContextPath() +"/auth/accessDenied");
  }
}
