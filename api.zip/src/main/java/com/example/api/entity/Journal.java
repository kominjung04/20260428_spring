package com.example.api.entity;

import jakarta.persistence.*;
import lombok.ToString;

@Entity
@ToString
public class Journal extends BasicEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String title;
  private String content;

  @ManyToOne(fetch = FetchType.LAZY)
  private Members members;


}
